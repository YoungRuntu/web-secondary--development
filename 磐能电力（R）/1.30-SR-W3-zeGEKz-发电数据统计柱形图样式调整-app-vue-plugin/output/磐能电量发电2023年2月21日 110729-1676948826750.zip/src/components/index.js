import DesignConfiguration from "./designConfiguration/App.vue";
import Main from "./main/App.vue";
import Development from "./development/App.vue";

export {
  DesignConfiguration,
  Main,
  Development
};
