const commonConfig = require('../../gulpfile');

exports.default = commonConfig.default;
