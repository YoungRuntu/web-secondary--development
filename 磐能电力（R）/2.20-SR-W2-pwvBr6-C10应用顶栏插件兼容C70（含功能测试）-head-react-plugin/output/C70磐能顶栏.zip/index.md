---
title: 组件开发预览
nav:
  title: 应用
  path: /app
group:
  title: 组件开发预览
  path: /dev
  order: 5
toc: menu
---

<code src="./demo/Preview.jsx" />
