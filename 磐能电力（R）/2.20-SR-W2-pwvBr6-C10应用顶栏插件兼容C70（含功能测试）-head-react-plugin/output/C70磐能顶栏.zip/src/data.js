export const testData = [
    {
      "message_level": "1",
      "message_content": "汇流箱故障",
      "device_type": "2",
      "device_name": "汇流箱B01",
      "code": "SB10002",
      "create_time": "1900/1/0  0:00:00",
      "status":"在线"
    },
    {
      "message_level": "1",
      "message_content": "告警",
      "device_type": "1",
      "device_name": "逆变器A01",
      "code": "SB10001",
      "create_time": "1900/1/0  0:00:00",
      "status":"离线"
    },
    {
        "message_level": "1",
        "message_content": "告警",
        "device_type": "1",
        "device_name": "逆变器A01",
        "code": "SB10001",
        "create_time": "1900/1/0  0:00:00",
        "status":"异常"
      }
  ];